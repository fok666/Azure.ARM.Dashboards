
if (interval) {
    clearInterval(interval);
    interval = 0;
} else {
	var interval = setInterval(function() {
		btn_elip=document.querySelectorAll(".fxs-tile-actionbar-action.fxs-portal-svg.fxs-tile-actionbar-command-opencontextmenu");
		btn_elip.forEach(function(a){a.click()},this);
		btn_refr=document.querySelectorAll(".fxs-contextMenu-item.msportalfx-command-like-button.fxs-portal-hover");
		btn_refr.forEach(function(a){if(a.innerText == 'Refresh') a.click()},this);
		btn_ref=document.querySelectorAll(".azc-toolbarButton-container");
		btn_ref.forEach(function(a){if(a.title.includes("Refresh")) a.click()},this);
	}, 60 * 1000 )
}
